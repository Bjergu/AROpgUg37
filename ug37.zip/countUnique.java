public class countUnique {

    public static int countUnique(int arr[], int n){

        int res = 0;
        for (int i = 0; i < n; i++){
            while (i < n - 1 && arr[i] == arr[i + 1]){
                i++;
            }
            res++;
        }
        return res;
    }
}
