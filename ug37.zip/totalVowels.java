import java.util.ArrayList;

public class totalVowels {

    public static int totalVowels(){

        ArrayList<String> totalVowels = new ArrayList<String>();
        totalVowels.add("Hello");
        totalVowels.add("Hej");
        totalVowels.add("Yo");
        totalVowels.add("Carrot");
        totalVowels.add("Moon");

        System.out.println(totalVowels);

        if (totalVowels.isEmpty())
            return 0;

        int count = 0;

        for (int i = 0; i < totalVowels.size(); i++){
            String str = totalVowels.get(i);

            for (int j = 0; j < str.length(); j++){
                char ch = Character.toLowerCase(str.charAt(j));

                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'){
                    count++;
                }
            }
        }
        return count;
    }
}
