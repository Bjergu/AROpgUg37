import java.util.ArrayList;
import java.util.Map;

public class removeOdd {

    public static void remoweOddLength(){

        ArrayList<String> remOdd = new ArrayList<String>();
        remOdd.add("Hello");
        remOdd.add("Dog");
        remOdd.add("Mama");
        remOdd.add("Grandfather");
        remOdd.add("Animal");
        remOdd.add("Bo");
        remOdd.add("Boomerang");
        remOdd.add("Matrioszka");

        System.out.println("Before: \n" + remOdd);

        for (int i = remOdd.size() - 1; i >= 0; i--){
            String str = remOdd.get(i);


            if (str.length() % 2 == 1){
                remOdd.remove(str);
            }
        }
        System.out.println("After odd words removed: \n" + remOdd);
    }
}

