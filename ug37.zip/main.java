import java.util.ArrayList;

public class main {

    public static void main(String[] args){

        System.out.println("Number of vowels in arrayList: " + totalVowels.totalVowels());
        System.out.println();

        int arr[] = {22, 33, 44, 1, 22, 22, 1, 33, 18};
        int n = arr.length;
        System.out.println("Uniqie values count: " + countUnique.countUnique(arr, n));
        System.out.println();

        minLength.minLength();
        System.out.println();

        removeOdd.remoweOddLength();
        System.out.println();
    }
}
