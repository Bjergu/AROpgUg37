import java.util.ArrayList;

public class minLength {

    public static void minLength(){

        ArrayList<String> totalVowels = new ArrayList<String>();
        totalVowels.add("Hello");
        totalVowels.add("Brother");
        totalVowels.add("Lets");
        totalVowels.add("Go");
        totalVowels.add("Party");

        System.out.println(totalVowels);

        if (totalVowels.isEmpty())
            System.out.println("0");

        String shortest = totalVowels.get(0);

        for (String str : totalVowels){
            if (str.length() < shortest.length()){
                shortest = str;
            }
        }
        System.out.println("The shortest string: " + shortest);
    }
}
